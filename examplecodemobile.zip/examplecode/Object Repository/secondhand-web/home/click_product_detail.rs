<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>click_product_detail</name>
   <tag></tag>
   <elementGuidId>8c72acf2-5dde-4000-8ab0-e02ad6f15602</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@alt, 'Product Donut')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@alt, 'Product Donut')]</value>
      <webElementGuid>c5fd3e4a-2c3f-4643-94e7-f665136a7216</webElementGuid>
   </webElementProperties>
</WebElementEntity>
