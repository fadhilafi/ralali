<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>verify_text_product_detail</name>
   <tag></tag>
   <elementGuidId>76469765-4280-4cf4-a123-d51cf25d527b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'card-title')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'card-title')]</value>
      <webElementGuid>7d1806b0-04c4-484c-9e4c-6e0b3d706b37</webElementGuid>
   </webElementProperties>
</WebElementEntity>
