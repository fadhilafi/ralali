<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>filter_hoby_button</name>
   <tag></tag>
   <elementGuidId>18d6645e-bf40-4bf4-898e-2a66a65cf1fc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@data-icon, 'magnifying-glass')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@data-icon, 'magnifying-glass')]</value>
      <webElementGuid>29bd77e8-9ab2-45bc-b962-fad053bbeb9b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
