<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_masuk</name>
   <tag></tag>
   <elementGuidId>fa0bf708-1fbe-41b3-ac4e-b4c686da073f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'btn btn-primary w-100')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'nav-item-login')]</value>
      <webElementGuid>83669731-e605-41ab-81dc-14fd37692121</webElementGuid>
   </webElementProperties>
</WebElementEntity>
