<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_hoby</name>
   <tag></tag>
   <elementGuidId>0450469c-2cab-4c3d-9ab4-30f12368a8e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@alt() = '${text}']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@alt() = '${text}']</value>
      <webElementGuid>f4a21eaf-850d-4586-afb5-bdf41ec902a5</webElementGuid>
   </webElementProperties>
</WebElementEntity>
