<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>fill_hargaproduk</name>
   <tag></tag>
   <elementGuidId>d9413501-7e8b-49db-a449-f3b3b3d61827</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'harga_produk')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'harga_produk')]</value>
      <webElementGuid>6aafd905-84e2-48c4-a5df-cc1e5d5da9f0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
