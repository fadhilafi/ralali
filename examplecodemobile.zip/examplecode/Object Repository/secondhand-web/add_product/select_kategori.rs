<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_kategori</name>
   <tag></tag>
   <elementGuidId>c19fed7b-a546-4308-b79b-9d7e4abb6785</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'kategori')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'kategori')]</value>
      <webElementGuid>9487a400-f081-4735-9fee-3cd0b5dcd76d</webElementGuid>
   </webElementProperties>
</WebElementEntity>
