<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>fill_deskripsi</name>
   <tag></tag>
   <elementGuidId>b9eb41e1-1085-4472-b3aa-98f604b474d6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'deskripsi')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'deskripsi')]</value>
      <webElementGuid>ee053591-7dd6-48bd-af78-1c2bdf0ca422</webElementGuid>
   </webElementProperties>
</WebElementEntity>
