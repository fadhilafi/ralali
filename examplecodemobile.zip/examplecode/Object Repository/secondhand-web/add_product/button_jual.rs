<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_jual</name>
   <tag></tag>
   <elementGuidId>7336ebf1-1b71-46c0-8cf2-e546effb275c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'btn btn-color-theme pl-3 pr-3 button-jual')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'btn btn-color-theme pl-3 pr-3 button-jual')]</value>
      <webElementGuid>0288a8f3-9172-4616-91fb-ddeaff880db9</webElementGuid>
   </webElementProperties>
</WebElementEntity>
