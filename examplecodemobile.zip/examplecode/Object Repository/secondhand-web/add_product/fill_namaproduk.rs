<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>fill_namaproduk</name>
   <tag></tag>
   <elementGuidId>828e2377-377f-4451-a868-ce1a5d369cb8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'nm_produk')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'nm_produk')]</value>
      <webElementGuid>e109c463-e28b-478e-bf89-e203a3117f98</webElementGuid>
   </webElementProperties>
</WebElementEntity>
