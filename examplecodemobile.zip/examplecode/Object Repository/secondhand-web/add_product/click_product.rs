<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>click_product</name>
   <tag></tag>
   <elementGuidId>4f0a6213-58ec-4df0-bd77-8b4542a6dcde</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'card-title') and text() = '${text}']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'card-title') and text() = '${text}']</value>
      <webElementGuid>ed2b1747-7dce-43c4-a67e-5dda1cdc1951</webElementGuid>
   </webElementProperties>
</WebElementEntity>
