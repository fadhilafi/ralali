<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>edit_button</name>
   <tag></tag>
   <elementGuidId>95cc8560-b092-45a2-bb95-41092cf97943</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'btn btn-outline-primary')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'btn btn-outline-primary')]</value>
      <webElementGuid>b39b5ba5-102f-40c5-810e-ad14fb7bd8f6</webElementGuid>
   </webElementProperties>
</WebElementEntity>
