<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>preview_product</name>
   <tag></tag>
   <elementGuidId>60a94d9a-62c7-4405-8c53-d6397264898e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'btn btn-outline-primary')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'btn btn-outline-primary')]</value>
      <webElementGuid>97d148e4-6215-4de8-9643-3d68105523d8</webElementGuid>
   </webElementProperties>
</WebElementEntity>
