<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>daftarjual_button</name>
   <tag></tag>
   <elementGuidId>8af0e559-e6da-4406-a42f-c082ced3020e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'svg-inline--fa fa-list fa-lg ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'svg-inline--fa fa-list fa-lg ')]</value>
      <webElementGuid>e401a385-0396-49ca-bb0b-65ad4e1b1acf</webElementGuid>
   </webElementProperties>
</WebElementEntity>
