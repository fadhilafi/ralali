<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_tertarik</name>
   <tag></tag>
   <elementGuidId>67268731-0935-4247-8aa3-cdaa2ece761a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'btn btn-primary')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'btn btn-primary')]</value>
      <webElementGuid>5ef12e65-17be-47f6-8491-9002c60b706b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
