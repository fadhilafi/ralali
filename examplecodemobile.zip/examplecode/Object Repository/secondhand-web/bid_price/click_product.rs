<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>click_product</name>
   <tag></tag>
   <elementGuidId>fdec539a-9584-4925-9c14-7cdee0a79f98</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'card-title') and text() = '${text}']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'card-title') and text() = '${text}']</value>
      <webElementGuid>151153d3-8133-4d48-b136-dd19d91a397e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
