<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_email</name>
   <tag></tag>
   <elementGuidId>53e19736-0595-465f-80e3-381b32dc21d9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'exampleInputEmail1')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'exampleInputEmail1')]</value>
      <webElementGuid>6ffdb6ed-d352-4f7a-8436-0c10961d813b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
