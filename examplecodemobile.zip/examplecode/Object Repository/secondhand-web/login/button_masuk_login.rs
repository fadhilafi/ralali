<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_masuk_login</name>
   <tag></tag>
   <elementGuidId>35323260-fffa-461b-ae11-7bd3d73e3228</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'nav-item-login')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'nav-item-login')]</value>
      <webElementGuid>265cc7c4-e423-4f4d-98a5-3380212be807</webElementGuid>
   </webElementProperties>
</WebElementEntity>
