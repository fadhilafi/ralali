<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>verify_text_kategori_beranda</name>
   <tag></tag>
   <elementGuidId>e645dec1-adf8-49d7-95e7-b6f8622cc94e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'card-title')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'card-title')]</value>
      <webElementGuid>6107b01a-7eaf-4d95-824f-9619d3d8bb68</webElementGuid>
   </webElementProperties>
</WebElementEntity>
