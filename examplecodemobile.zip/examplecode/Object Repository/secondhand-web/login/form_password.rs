<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_password</name>
   <tag></tag>
   <elementGuidId>5e4cfff1-afe8-4f33-9d4c-b81f23a1fa9c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'exampleInputPassword1')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'exampleInputPassword1')]</value>
      <webElementGuid>9696d08e-9c60-4942-bb89-3331dc0dab86</webElementGuid>
   </webElementProperties>
</WebElementEntity>
