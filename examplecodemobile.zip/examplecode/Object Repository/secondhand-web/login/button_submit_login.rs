<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_submit_login</name>
   <tag></tag>
   <elementGuidId>0828d6e8-3adc-4733-a0b8-f427d2b4839c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'btn btn-primary w-100')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'btn btn-primary w-100')]</value>
      <webElementGuid>16c4fef0-9899-4b6d-b2cd-b92de51d828a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
