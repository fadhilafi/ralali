<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>verify_text_unsuccessful</name>
   <tag></tag>
   <elementGuidId>35eb25d5-3b3a-4007-8f1a-f6b69a128907</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'mt-4 text-center cta')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'mt-4 text-center cta')]</value>
      <webElementGuid>f18ca523-5e43-460d-928b-f3fd0b36410f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
