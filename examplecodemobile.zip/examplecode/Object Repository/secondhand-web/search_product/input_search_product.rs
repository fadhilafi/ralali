<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_search_product</name>
   <tag></tag>
   <elementGuidId>cce3c7aa-f3c3-473f-a48a-166c48d670f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'form-control cari-produk')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'form-control cari-produk')]</value>
      <webElementGuid>930ec9c1-0d91-4ffd-acb0-08f7137304fa</webElementGuid>
   </webElementProperties>
</WebElementEntity>
