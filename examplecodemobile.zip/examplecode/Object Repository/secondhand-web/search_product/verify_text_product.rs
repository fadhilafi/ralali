<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>verify_text_product</name>
   <tag></tag>
   <elementGuidId>652ddadf-e0e6-49bf-be04-35baa2ef222b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'card-title')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'card-title')]</value>
      <webElementGuid>0a0af645-d9ef-476d-bdd0-421442ce87d6</webElementGuid>
   </webElementProperties>
</WebElementEntity>
