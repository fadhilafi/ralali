<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_product_item_dynamic</name>
   <tag></tag>
   <elementGuidId>bee6dfc0-1117-41b3-be89-521798d93847</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'card-title') and text()='${text}']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'card-title') and text()='${text}']</value>
      <webElementGuid>23275fb5-923c-4292-b733-fbce3a603c20</webElementGuid>
   </webElementProperties>
</WebElementEntity>
