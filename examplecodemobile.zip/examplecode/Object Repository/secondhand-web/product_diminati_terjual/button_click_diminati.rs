<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_click_diminati</name>
   <tag></tag>
   <elementGuidId>23cfe357-8294-4f83-87ce-511a86ccd681</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@viewBox,'0 0 512 512')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@viewBox,'0 0 512 512')]</value>
      <webElementGuid>a62a40bc-7f0c-47f4-8f0d-2956e0dbd58f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
