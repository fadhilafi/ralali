<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_masuk_login</name>
   <tag></tag>
   <elementGuidId>31643912-aac9-47ed-9605-c6fba5562f2a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'navbar-nav navbar-top')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'navbar-nav navbar-top')]</value>
      <webElementGuid>88648b8b-5d18-4f6f-b468-3a411cb20dc6</webElementGuid>
   </webElementProperties>
</WebElementEntity>
