<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_submit_login</name>
   <tag></tag>
   <elementGuidId>2a88d00f-ed62-4e03-ae76-99b6b3e37b3c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'btn btn-primary w-100')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'btn btn-primary w-100')]</value>
      <webElementGuid>a4f5043c-6c5f-4563-8bac-03b650be4bc3</webElementGuid>
   </webElementProperties>
</WebElementEntity>
