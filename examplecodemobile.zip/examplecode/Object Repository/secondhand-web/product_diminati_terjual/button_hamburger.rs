<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_hamburger</name>
   <tag></tag>
   <elementGuidId>ecd87cec-bf9f-4cc8-98fe-7f5dbcebbe4b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'svg-inline--fa fa-list fa-lg ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'svg-inline--fa fa-list fa-lg ')]</value>
      <webElementGuid>6f586a95-8a43-47a9-aa9f-188bd5b11a31</webElementGuid>
   </webElementProperties>
</WebElementEntity>
