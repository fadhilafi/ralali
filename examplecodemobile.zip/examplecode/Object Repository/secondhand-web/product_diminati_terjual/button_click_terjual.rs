<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_click_terjual</name>
   <tag></tag>
   <elementGuidId>cb5dadfc-e80e-4030-ab6b-e13b8aba5261</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@viewBox,'0 0 288 512')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@viewBox,'0 0 288 512')]</value>
      <webElementGuid>30e9b766-c2a6-41dd-80dd-4c7b7a143fa9</webElementGuid>
   </webElementProperties>
</WebElementEntity>
