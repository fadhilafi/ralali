<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_password</name>
   <tag></tag>
   <elementGuidId>e5c7a7f1-04f7-4a0b-a368-bfc19ca356e1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'exampleInputPassword1 ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'exampleInputPassword1 ')]</value>
      <webElementGuid>28b98042-17f9-4ca0-858b-10205c55b301</webElementGuid>
   </webElementProperties>
</WebElementEntity>
