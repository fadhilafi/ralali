<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_daftar_disini</name>
   <tag></tag>
   <elementGuidId>246ef8e3-ec3e-41ce-9706-b1badc41c33b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@href, 'mt-4 text-center cta')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@href, 'signup')]</value>
      <webElementGuid>691a06a9-3792-4b20-aa9a-a020387ff10b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
