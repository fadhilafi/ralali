<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_daftar</name>
   <tag></tag>
   <elementGuidId>356b0e7f-9d6b-4fe0-9215-64e479ce00a7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'btn btn-primary w-100')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'btn btn-primary w-100')]</value>
      <webElementGuid>6d10fd2e-ce06-4cab-a5a1-9bc6bd1d1bdc</webElementGuid>
   </webElementProperties>
</WebElementEntity>
