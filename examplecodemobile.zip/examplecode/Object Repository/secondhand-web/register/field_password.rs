<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>field_password</name>
   <tag></tag>
   <elementGuidId>74370648-8808-45cb-be1d-82cb9e357c19</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'exampleInputPassword1 ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'exampleInputPassword1 ')]</value>
      <webElementGuid>10243768-bf3c-4ba1-af46-439afb7289b5</webElementGuid>
   </webElementProperties>
</WebElementEntity>
