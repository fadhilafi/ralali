<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_masuk</name>
   <tag></tag>
   <elementGuidId>038c12c7-fe55-48f0-ab5a-f79401d5b7f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'nav-item-login')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class, 'nav-item-login')]</value>
      <webElementGuid>0100b9e2-9c52-4a2f-9447-d2c48580da11</webElementGuid>
   </webElementProperties>
</WebElementEntity>
