<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>field_email_address</name>
   <tag></tag>
   <elementGuidId>d7988f3e-de34-43e1-a00d-bb352872bbd8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'exampleInputEmail1')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'exampleInputEmail1')]</value>
      <webElementGuid>0cc3d8cf-f2b6-417f-b3b3-4bf4596a3409</webElementGuid>
   </webElementProperties>
</WebElementEntity>
