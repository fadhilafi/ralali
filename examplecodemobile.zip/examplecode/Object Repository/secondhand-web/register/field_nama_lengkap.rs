<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>field_nama_lengkap</name>
   <tag></tag>
   <elementGuidId>4b038d25-c611-4e55-a3d2-0bf8eca557ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'inputAddress')]
</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'inputAddress')]
</value>
      <webElementGuid>144c28e9-f477-48c0-9c10-5a97183ef9b3</webElementGuid>
   </webElementProperties>
</WebElementEntity>
