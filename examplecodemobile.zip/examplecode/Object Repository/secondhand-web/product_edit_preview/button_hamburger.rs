<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_hamburger</name>
   <tag></tag>
   <elementGuidId>a34d2546-2e1e-4f98-88d9-46871b3eced7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'svg-inline--fa fa-list fa-lg ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'svg-inline--fa fa-list fa-lg ')]</value>
      <webElementGuid>f47aeba9-6dbb-414b-b9b3-00dda8f8babf</webElementGuid>
   </webElementProperties>
</WebElementEntity>
