<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_masuk_login</name>
   <tag></tag>
   <elementGuidId>35d62054-fdd4-463d-84f7-9a35aacb49ff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'navbar-nav navbar-top')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'navbar-nav navbar-top')]</value>
      <webElementGuid>f7b76172-a677-498a-835d-5d37f7001a1d</webElementGuid>
   </webElementProperties>
</WebElementEntity>
