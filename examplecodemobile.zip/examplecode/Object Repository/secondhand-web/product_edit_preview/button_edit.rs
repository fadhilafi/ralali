<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_edit</name>
   <tag></tag>
   <elementGuidId>447e1ff0-153e-4ccd-bd74-48d0a774ef70</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'btn btn-outline-primary')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'btn btn-outline-primary')]</value>
      <webElementGuid>24508d81-7d61-4d23-a69c-a9d8caf0fff1</webElementGuid>
   </webElementProperties>
</WebElementEntity>
