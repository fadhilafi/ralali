<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>click_product</name>
   <tag></tag>
   <elementGuidId>75d394b4-8b0c-41cc-9a34-07a7cc8d2cfd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'card-body')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@alt,'Product Kacamata')]</value>
      <webElementGuid>91d81258-7daf-43ce-8725-cab9a656e28c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
