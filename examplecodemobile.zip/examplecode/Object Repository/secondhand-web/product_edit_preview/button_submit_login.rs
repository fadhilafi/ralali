<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_submit_login</name>
   <tag></tag>
   <elementGuidId>f2bd4933-1558-46ac-965b-f984e6d0413c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'btn btn-primary w-100')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'btn btn-primary w-100')]</value>
      <webElementGuid>e72abb74-ca5f-40fa-93bb-249bef86d83b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
