<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_password</name>
   <tag></tag>
   <elementGuidId>5ea31112-7379-428a-a233-ac228be79354</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'exampleInputPassword1 ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'exampleInputPassword1 ')]</value>
      <webElementGuid>672753a3-0752-4543-bd74-eec41d73f568</webElementGuid>
   </webElementProperties>
</WebElementEntity>
