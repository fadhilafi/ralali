<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_preview</name>
   <tag></tag>
   <elementGuidId>954c0aee-f0fc-4aa3-ac77-ef139d26a24a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'col-md mb-3 d-grid')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'col-md mb-3 d-grid')]</value>
      <webElementGuid>875d18e9-b751-49a3-9d0e-541fffc54813</webElementGuid>
   </webElementProperties>
</WebElementEntity>
