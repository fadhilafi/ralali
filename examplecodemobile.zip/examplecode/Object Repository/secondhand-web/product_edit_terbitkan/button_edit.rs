<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_edit</name>
   <tag></tag>
   <elementGuidId>75324627-4ac3-45bd-b2ce-4933ebad51da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'btn btn-outline-primary')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'btn btn-outline-primary')]</value>
      <webElementGuid>1ddadae6-1eb7-459f-8e1d-a3468334925e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
