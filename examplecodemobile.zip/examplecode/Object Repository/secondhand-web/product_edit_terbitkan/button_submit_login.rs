<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_submit_login</name>
   <tag></tag>
   <elementGuidId>f7580121-67f6-4932-a047-4dc9470cdb5b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'btn btn-primary w-100')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'btn btn-primary w-100')]</value>
      <webElementGuid>6f8fa5fa-c976-471b-a869-c2d175381a6b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
