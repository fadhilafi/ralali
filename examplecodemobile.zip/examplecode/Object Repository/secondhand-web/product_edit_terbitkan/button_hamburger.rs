<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_hamburger</name>
   <tag></tag>
   <elementGuidId>0f489ed2-219d-467a-9927-0c67d6d43466</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'svg-inline--fa fa-list fa-lg ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'svg-inline--fa fa-list fa-lg ')]</value>
      <webElementGuid>7dd95c47-057f-4174-856c-034c4759cf4c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
