<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>click_product</name>
   <tag></tag>
   <elementGuidId>7fbe4fd4-97e8-41e1-be1d-44f9c446edec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'card-body')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@alt,'Product Kacamata')]</value>
      <webElementGuid>ce04d4f1-1b34-4525-bf92-51624c3101c0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
