<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_terbitkan</name>
   <tag></tag>
   <elementGuidId>f6877699-6066-4938-84a9-5ef1c6bb5acb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'col-md mb-3 d-grid')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'col-md mb-3 d-grid')]</value>
      <webElementGuid>0d5aab49-b4be-4a2c-921c-c1fd33ea8791</webElementGuid>
   </webElementProperties>
</WebElementEntity>
