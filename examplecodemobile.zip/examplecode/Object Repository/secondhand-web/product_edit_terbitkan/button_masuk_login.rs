<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_masuk_login</name>
   <tag></tag>
   <elementGuidId>8f43aed4-5ced-4f18-a426-20a4fd865d29</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'navbar-nav navbar-top')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'navbar-nav navbar-top')]</value>
      <webElementGuid>b7d24b9b-b94e-4ecd-897a-4a9505a510eb</webElementGuid>
   </webElementProperties>
</WebElementEntity>
