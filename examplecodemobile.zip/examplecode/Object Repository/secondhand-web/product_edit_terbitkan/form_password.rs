<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_password</name>
   <tag></tag>
   <elementGuidId>c9b19c7b-f015-49cc-9dc4-73a04cbc52d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@id, 'exampleInputPassword1 ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id, 'exampleInputPassword1 ')]</value>
      <webElementGuid>a6abf93c-ffcd-401a-b74d-9fe8d335902a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
