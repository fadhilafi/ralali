<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>textarea_i</name>
   <tag></tag>
   <elementGuidId>3448cdd8-350f-478a-9156-bdb1e7ca3451</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#deskripsi</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>












</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>textarea</value>
      <webElementGuid>e526698f-87f2-4807-90d4-8ea1b0d9ac7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>c5c01127-580e-465f-bdad-583b9140a9e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>deskripsi</value>
      <webElementGuid>2fde2152-815a-4303-ade1-df0dc31c62a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>rows</name>
      <type>Main</type>
      <value>3</value>
      <webElementGuid>03916e40-328a-4200-b78e-7d423837b232</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>placeholder</name>
      <type>Main</type>
      <value>Contoh: Jalan Ikan Hiu 33</value>
      <webElementGuid>cfa7067c-5df4-484f-b593-21f91be46050</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>f5cd2fd7-2980-4aa6-95f7-f0397c2032b2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;deskripsi&quot;)</value>
      <webElementGuid>367995c9-2b24-4b4a-8f58-645438dc732c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//textarea[@id='deskripsi']</value>
      <webElementGuid>2225db53-dffb-4d8c-982e-f33f39fd40d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/form/div[4]/textarea</value>
      <webElementGuid>5538956f-5097-4234-ab27-05f92caea1a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Deskripsi'])[1]/following::textarea[1]</value>
      <webElementGuid>855b31e8-4e56-4ba4-a027-202ef867bf01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kategori'])[1]/following::textarea[1]</value>
      <webElementGuid>b85cb07b-50ae-4693-b878-598ee872f154</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Foto Produk'])[1]/preceding::textarea[1]</value>
      <webElementGuid>179ae8e9-61ff-42ed-ab80-93cf8efba47b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Preview'])[1]/preceding::textarea[1]</value>
      <webElementGuid>d32ce33b-9a62-4b8f-8c8b-458bbf317aff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='i']/parent::*</value>
      <webElementGuid>4551dcc9-cf9d-428f-9817-4d57991f28a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//textarea</value>
      <webElementGuid>4e84c3b0-e9be-4bd2-8bda-c8a0c2a223ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//textarea[@id = 'deskripsi' and @placeholder = 'Contoh: Jalan Ikan Hiu 33' and (text() = 'i' or . = 'i')]</value>
      <webElementGuid>f2a4299d-6803-4ed3-84f3-5900b4276f93</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
